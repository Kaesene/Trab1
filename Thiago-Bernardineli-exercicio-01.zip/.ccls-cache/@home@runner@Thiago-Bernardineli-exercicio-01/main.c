#include <stdio.h>

int main() {
  int n1,n2,n3,media;
  printf("Digite A primeira Nota\n");
  scanf("%d",&n1);
  printf("Digite A segunda Nota\n");
  scanf("%d",&n2);
  printf("Digite A terceira Nota\n");
  scanf("%d",&n3);
  media = (n1+n2+n3)/3;
  printf("Sua media é igual a : %d",media);
}